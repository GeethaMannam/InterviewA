﻿using System;
using System.Collections.Generic;
using System.Text;
using Bank.Interfaces;
namespace Bank
{
   public class Owner : IOwner
    {
    }
}
