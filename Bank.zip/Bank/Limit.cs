﻿using System;
using System.Collections.Generic;
using System.Text;
using Bank.Interfaces;

namespace Bank
{
    public class Limit : Ilimit
    {
        public int withdrawLimit { get; set; }
    }
}
