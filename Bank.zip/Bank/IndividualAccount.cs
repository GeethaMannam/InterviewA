﻿using System;
using System.Collections.Generic;
using System.Text;
using Bank.Interfaces;

namespace Bank
{
   public class IndividualAccount : Account, IIndividual
    {
        Limit limit;
        IndividualAccount(Ilimit limit)
        {
            this.limit = (Limit)limit;
        }
    }
}
