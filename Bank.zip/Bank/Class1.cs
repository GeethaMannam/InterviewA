﻿using System;

namespace Bank
{
    public class Class1
    {
    }
}
