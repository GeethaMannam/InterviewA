﻿using System;
using System.Collections.Generic;
using System.Text;
using Bank.Interfaces;
namespace Bank
{
   public class Withdraw : IWithdraw
    {

        Account account; 
        public Withdraw(IAccount accountInfo, ITransaction transaction,Ilimit limit)
        {
            account = (Account)accountInfo;
            //rest of the code goes here..
          
        }
    }
}
