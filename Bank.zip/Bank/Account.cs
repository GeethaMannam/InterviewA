﻿using System;
using System.Collections.Generic;
using System.Text;
using Bank.Interfaces;

namespace Bank
{
    public class Account : IAccount
    {
        public int balance { get; set; }
        public IOwner owner { get; set; }
        public ITransaction transaction { get; set; }

       public Account(ITransaction transaction)
        {
            this.transaction = transaction;
        }
        public Account()
        {
            
        }
    }
}
