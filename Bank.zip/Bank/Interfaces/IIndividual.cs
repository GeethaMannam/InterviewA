﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bank.Interfaces
{
    public interface IIndividual : IInvesment
    {
    }
}
