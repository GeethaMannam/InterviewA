﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bank.Interfaces
{
    public interface ITransaction
    {
         int timeout { get; set; }
        int amount { get; set; }
    }
}
