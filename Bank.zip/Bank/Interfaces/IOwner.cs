﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bank.Interfaces
{
    // user
    public interface IOwner
    {
         string name { get; set; }
         string address { get; set; }
    }
}
