﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bank.Interfaces
{
    public interface IBank
    {
        // read from config file etc
         string name { get; set; }
    }
}
