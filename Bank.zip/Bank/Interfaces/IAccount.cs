﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bank.Interfaces
{
    public interface IAccount
    {
         int balance { get; set; }
         IOwner owner { get; set; }
        ITransaction transaction { get; set; }
    }
}
