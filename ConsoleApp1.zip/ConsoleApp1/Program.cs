﻿using System;
using System.Collections.Generic;
using System.Linq;


namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] allLocations = { { 1, -3 },{ 1, 2 },{ 3, 4 } };
            nearestXsteakHouses(3, allLocations, 1);
        }



        public static List<List<int>> nearestXsteakHouses(int totalSteakhouses,
                                            int[,] allLocations,
                                            int numSteakhouses)
        {
            double distance = 0;
            string s = null;

            List<int> location = new List<int>();
            List<List<int>> nearlocations = new List<List<int>>();
            // int[,,] nearlocationsarray = new int[totalSteakhouses,,];
            Dictionary<double, List<int>> dict = new Dictionary<double, List<int>>();

            for (int i = 0; i < totalSteakhouses; i++)
            {
                distance = Math.Sqrt(Math.Pow(allLocations[i, 0], 2) + Math.Pow(allLocations[i, 1], 2));
                location = new List<int>();
                location.Add(allLocations[i, 0]);
                location.Add(allLocations[i, 1]);
                if (dict.Keys.Count < numSteakhouses)
                {
                    dict.Add(distance, location);

                }
                else
                {
                    if (dict.Keys.Max() > distance)
                    {
                        dict.Remove(dict.Keys.Max());
                        dict.Add(distance, location);
                    }


                }



            }

            foreach (List<int> i in dict.Values)
            {
                nearlocations.Add(i);
            }

            return nearlocations;


        }
    }
}
